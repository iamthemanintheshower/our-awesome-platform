<?php

//echo __DIR__; // # use this to configure the .htaccess file